<?php
// Simple landing page for SRC Website Management
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>SRC Website Management</title>

  <!-- Fonts & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    :root{
      --bg:#0f1724;
      --card:#0b1220;
      --glass: rgba(255,255,255,0.04);
      --accent:#4f46e5;
      --accent-2:#06b6d4;
      --muted: rgba(255,255,255,0.6);
      --glass-2: rgba(255,255,255,0.03);
      font-family: 'Inter', system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    html,body{height:100%}
    body{
      margin:0;
      background: radial-gradient(1200px 600px at 10% 10%, rgba(79,70,229,0.12), transparent),
                  radial-gradient(900px 500px at 90% 90%, rgba(6,182,212,0.06), transparent),
                  var(--bg);
      color:#e6eef8;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      overflow-x:hidden;
    }

    /* Top nav */
    .nav {
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:20px 28px;
      gap:16px;
      position:sticky;
      top:0;
      z-index:40;
      backdrop-filter: blur(6px);
      background: linear-gradient(180deg, rgba(11,17,28,0.35), rgba(11,17,28,0.06));
    }
    .brand { display:flex; align-items:center; gap:12px; text-decoration:none; color:inherit; }
    .brand .logo {
      width:44px; height:44px; border-radius:10px;
      background: linear-gradient(135deg,var(--accent),var(--accent-2));
      display:flex; align-items:center; justify-content:center; font-weight:800; box-shadow: 0 8px 24px rgba(6,11,30,0.6);
    }
    .brand h1{font-size:16px;margin:0}
    .nav .actions { display:flex; gap:10px; align-items:center; }

    .btn {
      appearance:none; border:0; padding:10px 14px; border-radius:10px;
      font-weight:600; cursor:pointer; color:#07203a; background:linear-gradient(90deg,var(--accent),var(--accent-2));
      box-shadow: 0 6px 20px rgba(79,70,229,0.18), inset 0 -2px 6px rgba(255,255,255,0.04);
      transition: transform .18s ease, box-shadow .18s ease;
    }
    .btn:active{ transform:translateY(1px) scale(.997) }
    .btn.ghost{ background:transparent; color:var(--muted); border:1px solid rgba(255,255,255,0.03) }

    /* Hero */
    .hero {
      display:grid;
      grid-template-columns: 1fr 520px;
      gap:36px;
      padding:48px 28px 80px;
      align-items:center;
      max-width:1200px;
      margin:0 auto;
    }
    .hero-copy h2{
      margin:0 0 12px 0; font-size:38px; line-height:1.02;
      letter-spacing:-0.02em;
    }
    .hero-copy p { margin:0 0 20px 0; color:var(--muted); max-width:52ch; }

    .hero-visual {
      perspective:1200px;
      display:flex; align-items:center; justify-content:center;
    }

    /* 3D stacked cards */
    .stack {
      width:420px; height:320px; position:relative;
      transform-style:preserve-3d;
    }
    .card {
      position:absolute; left:0; top:0; width:100%; height:100%;
      border-radius:18px; overflow:hidden; padding:18px;
      background: linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.02));
      box-shadow: 0 12px 40px rgba(2,6,23,0.6);
      transition: transform .35s cubic-bezier(.16,.84,.44,1), box-shadow .25s;
      transform-origin:center;
      display:flex; flex-direction:column; justify-content:space-between;
      border: 1px solid rgba(255,255,255,0.03);
    }
    .card .site { display:flex; gap:12px; align-items:center;}
    .site .fav { width:56px; height:56px; border-radius:10px; background:rgba(255,255,255,0.03); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:18px; }
    .card h3{ margin:0; font-size:18px }
    .card p{ margin:8px 0 0 0; color:var(--muted); font-size:13px }

    .card .meta { display:flex; gap:8px; align-items:center; color:var(--muted); font-size:13px; }

    .card.depth-1 { transform: translate3d( -18px, -14px, -30px) rotateX(6deg) rotateY(-6deg); }
    .card.depth-2 { transform: translate3d(0px, 0px, 0px); }
    .card.depth-3 { transform: translate3d(18px, 14px, 30px) rotateX(-6deg) rotateY(6deg); }

    .card:hover { transform: translateY(-8px) scale(1.01); box-shadow: 0 24px 80px rgba(2,6,23,0.6); }

    /* features */
    .features { display:grid; grid-template-columns:repeat(3,1fr); gap:18px; margin-top:30px; }
    .feature { background:var(--glass); border-radius:12px; padding:16px; min-height:110px; display:flex; gap:12px; align-items:flex-start; }
    .feature i { font-size:22px; color:var(--accent); width:42px; height:42px; display:flex; align-items:center; justify-content:center; border-radius:10px; background: linear-gradient(180deg, rgba(79,70,229,0.08), rgba(6,182,212,0.04)); }
    .feature h4{ margin:0 0 6px 0; font-size:15px }
    .feature p { margin:0; color:var(--muted); font-size:13px }

    /* small screens */
    @media (max-width:1000px){
      .hero { grid-template-columns:1fr; padding:36px 18px 60px; }
      .hero-visual { order: -1; margin-bottom:18px; justify-content:center }
      .stack{ width:92%; max-width:420px; height:260px; margin:0 auto }
      .features { grid-template-columns:repeat(2,1fr) }
    }
    @media (max-width:640px){
      .nav { padding:12px; }
      .brand h1{ font-size:14px }
      .hero-copy h2{ font-size:26px }
      .features { grid-template-columns:1fr; }
      .stack{ height:220px }
    }

    /* subtle entrance animations */
    .reveal { opacity:0; transform: translateY(14px) scale(.995); transition: opacity .6s ease, transform .6s cubic-bezier(.2,.9,.3,1); will-change:transform,opacity; }
    .reveal.show { opacity:1; transform:none; }

    /* footer */
    footer { padding:28px; text-align:center; color:var(--muted); font-size:14px; }
    .cta-row { display:flex; gap:12px; margin-top:18px; align-items:center; flex-wrap:wrap; }

    /* small decorative orb */
    .orb {
      position: absolute; right:-120px; top:-60px; width:320px; height:320px; border-radius:50%;
      background: radial-gradient(circle at 30% 30%, rgba(79,70,229,0.14), rgba(6,182,212,0.06) 40%, transparent 55%);
      filter: blur(36px); pointer-events:none; z-index:0;
    }

    /* Inline-SVG animation helpers (no external runtime) */
    
      /* Hero SVG network animation */
      .svg-hero { width:420px; height:320px; max-width:92vw; display:block; margin:0 auto; }
      .node { fill: rgba(255,255,255,0.12); }
      .node-accent { fill: url(#gradA); }
      .link { stroke: rgba(255,255,255,0.06); stroke-width:1.2; stroke-linecap:round; }
      .pulse { transform-origin:50% 50%; animation: pulse 2.6s ease-in-out infinite; }
      .orbit { transform-origin:50% 50%; animation: orbit 9s linear infinite; }

      @keyframes pulse {
        0% { transform: scale(1); opacity: .9 }
        50% { transform: scale(1.12); opacity: 1 }
        100% { transform: scale(1); opacity: .9 }
      }
      @keyframes orbit {
        0% { transform: rotate(0deg) }
        100% { transform: rotate(360deg) }
      }

      /* Secondary badge animation */
      .svg-badge { width:120px; height:100px; display:block; margin-top:12px; }
      .gear { transform-origin:50% 50%; animation: gear 5s cubic-bezier(.2,.6,.2,.9) infinite; }
      @keyframes gear { 0%{ transform:rotate(0deg) } 50%{ transform:rotate(12deg) } 100%{ transform:rotate(0deg) } }

    /* Add preview CSS (place near existing styles) */
    .screen-preview {
        position: absolute;
        inset: 10% 7% 10% 7%;
        border-radius: 6px;
        overflow: hidden;
        background: #071122;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .screen-preview iframe {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
        background: #fff;
    }
    .screen-preview .preview-fallback {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }
    /* thumbnail inside monitor tiles */
    .site-thumb img {
        width: 100%;
        height: 58px;
        object-fit: cover;
        border-radius: 4px;
        display:block;
    }
    .site-screen.active { outline: 2px solid rgba(79,70,229,0.14); box-shadow: 0 12px 36px rgba(2,6,23,0.35); }
  </style>

  </style>
</head>
<body>
  <div class="nav">
    <a class="brand" href="index.php">
      <div class="logo">SRC</div>
      <div>
        <h1>SRC Website Management</h1>
        <div style="font-size:12px;color:var(--muted)">Manage sites, monitor and secure</div>
      </div>
    </a>

    <div class="actions">
      <a class="btn ghost" href="login.php"><i class="fa-solid fa-right-to-bracket" style="margin-right:8px"></i> Admin Login</a>
      <a class="btn" href="dashboard.php"><i class="fa-solid fa-tachometer-alt" style="margin-right:8px"></i> Go to Dashboard</a>
    </div>
  </div>

  <main>
    <section class="hero" aria-labelledby="hero-title">
      <div class="hero-copy">
        <div class="reveal" style="transition-delay:.05s">
          <h2 id="hero-title">Website management made effortless — fast, secure, visual.</h2>
          <p>Manage multiple websites from a single dashboard with automated thumbnails, account security, and admin tools built for small teams.</p>

          <div class="cta-row">
            <a class="btn" href="dashboard.php">Get Started — Dashboard</a>
            <a class="btn ghost" href="signup.php">Request Access</a>
          </div>

          <div class="features reveal" style="margin-top:22px; transition-delay:.15s">
            <div class="feature">
              <i class="fa-solid fa-shield-halved"></i>
              <div>
                <h4>Secure by design</h4>
                <p>Per-account lockouts, audit trails and password hashing out of the box.</p>
              </div>
            </div>
            <div class="feature">
              <i class="fa-solid fa-layer-group"></i>
              <div>
                <h4>Visual management</h4>
                <p>Auto-generated thumbnails and card-based site previews make management quick.</p>
              </div>
            </div>
            <div class="feature">
              <i class="fa-solid fa-wrench"></i>
              <div>
                <h4>Admin tools</h4>
                <p>Unlock accounts, export audits, and manage admins from the panel.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Replace the previous .stack / svg block in the hero-visual with the computer model -->
      <div class="hero-visual">
        <div class="orb" aria-hidden="true"></div>

        <div class="computer-container reveal" id="computer">
          <div class="computer" id="computer-3d" aria-hidden="true">
            <div class="monitor">
              <div class="monitor-frame">
                <!-- live preview area (iframe appended here on demand) -->
                <div class="screen-preview" id="screen-preview" aria-hidden="true">
                  <img id="preview-fallback" class="preview-fallback" src="images/alpha.png" alt="Preview snapshot">
                  <!-- iframe will be inserted here by JS -->
                </div>

                <div class="screen" role="list" id="site-list">
                  <div class="site-screen" role="listitem" data-live-url="https://afeathertech.com" data-snapshot="images/alpha.png">
                    <div class="site-thumb"><img src="images/thumb_alpha.jpg" alt="Alpha thumbnail"></div>
                    <div class="site-info"><span>alpha.example</span><span class="meta">Active</span></div>
                  </div>
                  <div class="site-screen" role="listitem" data-live-url="https://beta.example" data-snapshot="images/beta.png">
                    <div class="site-thumb"><img src="images/thumb_beta.jpg" alt="Beta thumbnail"></div>
                    <div class="site-info"><span>beta.example</span><span class="meta">Pending</span></div>
                  </div>
                  <div class="site-screen" role="listitem" data-live-url="https://client.example" data-snapshot="images/client.png">
                    <div class="site-thumb"><img src="images/thumb_client.jpg" alt="Client thumbnail"></div>
                    <div class="site-info"><span>client.example</span><span class="meta">Staging</span></div>
                  </div>
                  <div class="site-screen" role="listitem" data-live-url="https://blog.example" data-snapshot="images/blog.png">
                    <div class="site-thumb"><img src="images/thumb_blog.jpg" alt="Blog thumbnail"></div>
                    <div class="site-info"><span>blog.example</span><span class="meta">Live</span></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="monitor-stand"></div>
            <div class="monitor-base"></div>
          </div>
        </div>

        <!-- keep the small badge svg for decorative effect -->
        <svg class="svg-badge reveal" viewBox="0 0 120 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img">
          <defs>
            <linearGradient id="gBadge" x1="0" x2="1">
              <stop offset="0%" stop-color="#4f46e5"/>
              <stop offset="100%" stop-color="#06b6d4"/>
            </linearGradient>
          </defs>
          <g transform="translate(60,50)">
            <g class="gear">
              <path d="M0 -28 L6 -22 L12 -24 L18 -16 L16 -10 L22 -6 L18 0 L22 6 L16 10 L18 16 L12 24 L6 22 L0 28 L-6 22 L-12 24 L-18 16 L-16 10 L-22 6 L-18 0 L-22 -6 L-16 -10 L-18 -16 L-12 -24 L-6 -22 Z" fill="url(#gBadge)" opacity="0.95"></path>
            </g>
            <circle r="10" fill="#071026" stroke="rgba(255,255,255,0.06)"></circle>
          </g>
        </svg>
      </div>
    </section>

    <section style="max-width:1100px;margin:0 auto;padding:28px;">
      <div class="reveal" style="transition-delay:.05s">
        <h3 style="margin-bottom:10px">Why teams choose SRC</h3>
        <p style="color:var(--muted); margin-top:0; max-width:76ch">A compact management tool focused on essential operations: site overview, admin security, and simple integrations. Animations and cards help you find what matters fast.</p>
      </div>
    </section>
  </main>

  <footer>
    <div class="reveal">© <?php echo date('Y'); ?> SRC Website Management — Built for clarity and speed.</div>
  </footer>

  <script>
    // scroll reveal
    (function(){
      const obs = new IntersectionObserver((entries)=> {
        entries.forEach(e => {
          if(e.isIntersecting) e.target.classList.add('show');
        });
      }, {threshold: 0.08});
      document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
    })();

    // small tilt for the 3D stack
    (function(){
      const comp = document.getElementById('computer-3d');
      if (!comp) return;
      const rect = () => comp.getBoundingClientRect();
      function onMove(e){
        const r = rect();
        const cx = r.left + r.width/2;
        const cy = r.top + r.height/2;
        const x = (e.clientX - cx) / r.width;
        const y = (e.clientY - cy) / r.height;
        const rx = (y * 8).toFixed(2);
        const ry = (-x * 12).toFixed(2);
        comp.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`;
      }
      comp.parentElement.addEventListener('mousemove', onMove);
      comp.parentElement.addEventListener('mouseleave', ()=> comp.style.transform = '');
    })();

    // make SVG reveal smoothly when visible
    (function(){
      const obs = new IntersectionObserver((entries)=> {
        entries.forEach(e => {
          if(e.isIntersecting) {
            e.target.classList.add('show');
          }
        });
      }, {threshold: 0.15});
      document.querySelectorAll('.reveal, .hero-svg, .svg-hero, .svg-badge').forEach(el => obs.observe(el));
    })();

    // Add JS to handle lazy iframe loading and fallback
    (function(){
      const list = document.getElementById('site-list');
      const preview = document.getElementById('screen-preview');
      const fallbackImg = document.getElementById('preview-fallback');
      let currentIframe = null;
      let loadTimer = null;

      function clearIframe() {
        if (currentIframe) {
          currentIframe.remove();
          currentIframe = null;
        }
        if (loadTimer) { clearTimeout(loadTimer); loadTimer = null; }
      }

      function showPreview(url, snapshot) {
        // show snapshot first
        fallbackImg.src = snapshot || fallbackImg.src;
        preview.setAttribute('aria-hidden', 'false');

        // remove previous iframe
        clearIframe();

        // create iframe but do not assume it will be allowed
        const iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.allow = "geolocation; microphone; camera; clipboard-read; clipboard-write; encrypted-media";
        iframe.style.opacity = '0';
        // append hidden until confirmed loaded
        preview.appendChild(iframe);
        currentIframe = iframe;

        let loaded = false;
        function onLoad() {
          loaded = true;
          iframe.style.transition = 'opacity .28s ease';
          iframe.style.opacity = '1';
          // hide fallback beneath iframe
          fallbackImg.style.display = 'none';
          iframe.removeEventListener('load', onLoad);
          if (loadTimer) { clearTimeout(loadTimer); loadTimer = null; }
        }
        iframe.addEventListener('load', onLoad);

        // timeout: if iframe not loaded in 2500ms assume blocked and remove it
        loadTimer = setTimeout(() => {
          if (!loaded) {
            // keep fallback visible, remove iframe
            try { iframe.remove(); } catch(e) {}
            currentIframe = null;
            fallbackImg.style.display = 'block';
          }
          loadTimer = null;
        }, 2500);
      }

      // click handler for tiles, also sets active style
      list.addEventListener('click', function(e){
        const tile = e.target.closest('.site-screen');
        if (!tile) return;
        // mark active
        document.querySelectorAll('.site-screen').forEach(s => s.classList.remove('active'));
        tile.classList.add('active');

        const url = tile.getAttribute('data-live-url');
        const snapshot = tile.getAttribute('data-snapshot');
        // only load iframe on non-mobile or when explicitly clicked
        showPreview(url, snapshot);
      });

      // Initialize preview with first tile snapshot
      (function initFirst() {
        const first = document.querySelector('.site-screen');
        if (!first) return;
        first.classList.add('active');
        const snapshot = first.getAttribute('data-snapshot');
        fallbackImg.src = snapshot || fallbackImg.src;
        // do not auto-load iframe on mobile to save resources; only load on click
        const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        if (!isTouch) {
          const url = first.getAttribute('data-live-url');
          showPreview(url, snapshot);
        }
      })();

    })();
  </script>
</body>
</html>
