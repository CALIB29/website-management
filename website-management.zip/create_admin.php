<?php
include 'database.php';

// --- Admin Credentials ---
$username = 'admin';
$password = 'admin246';
// -------------------------

// Hash the password for security
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hashed_password);

// Execute the statement
if ($stmt->execute()) {
    echo "Admin user '{$username}' created successfully!";
} else {
    echo "Error creating admin user: " . $stmt->error;
}

$stmt->close();
$conn->close();

?>
<br><br>
<p><b>Important:</b> Please delete this file (<code>create_admin.php</code>) now for security reasons.</p>
